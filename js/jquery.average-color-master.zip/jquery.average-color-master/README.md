jQuery.average-color
====================

Fetch the average color of an HTML `img`, for example:

```
$('img.photo').averageColor(); // returns an object with r, g and b properties
$('img.photo').averageColorAsString(); // returns "rgb(0,0,0)"
```

Works with jQuery or Zepto.

About
-----

I (@LeeMallabone) created this based on this stack overflow answer:
http://stackoverflow.com/questions/2541481/get-average-color-of-image-via-javascript
